package com.atguigu.web;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.lang.reflect.Method;

public  abstract class BaseServlet extends HttpServlet { //父类，目的是为了代码复用
    //父类继承HttpServlet,而子类继承BaseServlet
    public void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        //解决post请求中文乱码问题
        //一定要在获取请求之前调用才有效
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html;charset=UTF-8");

        String action = req.getParameter("action");//通过隐式域来获取是那个页面的请求
        // 获取 action 业务鉴别字符串，获取相应的业务 方法反射对象
        try{
            Method method = this.getClass().getDeclaredMethod(action,HttpServletRequest.class,HttpServletResponse.class);
            //System.out.println(method);
            //掉哦那个目标业务 方法
            method.invoke(this,req,resp);
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    //由于图书列表诗意get的方式提交的，但是boolServlet以及它的BaseServlet也没后它的父类，就只能写一个，然后调用post
    @Override
    public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }
}
