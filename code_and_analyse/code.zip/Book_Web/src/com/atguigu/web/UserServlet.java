package com.atguigu.web;

import com.atguigu.pojo.User;
import com.atguigu.service.UserService;
import com.atguigu.service.impl.UserServiceImpl;
import com.atguigu.utils.WebUtils;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Arrays;
import java.util.Map;

import static com.google.code.kaptcha.Constants.KAPTCHA_SESSION_KEY;

public class UserServlet extends BaseServlet {

    private UserService userService = new UserServiceImpl();

    protected void logout(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //1、销毁Session中用户登录的信息（或者销毁Session）
        req.getSession().invalidate();
        //2、重定向到首页（或登录页面）。
        resp.sendRedirect(req.getContextPath());
        System.out.println(req.getContextPath());
    }

    protected void login(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        System.out.println("login请求被激活了");
        //  1、获取请求的参数
        String username = req.getParameter("username");
        String password = req.getParameter("password");
        // 调用 userService.login()登录处理业务
        User loginUser = userService.login(new User(null, username, password, null));
        // 如果等于null,说明登录 失败!
        if (loginUser == null) {
            //登陆失败的话，把错误的信息和回显的信息存储到request表单域中
            req.setAttribute("msg","用户名或密码输入错误");//提示信息
            req.setAttribute("username",username);//把输入的信息回显到提示栏中

            //   跳回登录页面
            req.getRequestDispatcher("/pages/user/login.jsp").forward(req, resp);
        } else {
            // 登录 成功
            req.getSession().setAttribute("user",loginUser);//放到session域当中
            req.getSession().setAttribute("id",loginUser.getId());//为了得到用户id
            System.out.println(loginUser.getId());
            req.getRequestDispatcher("/pages/user/login_success.jsp").forward(req, resp);
        }
    }


    protected void regist(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 从谷歌生成验证码的架包的常量KAPTCHA_SESSION_KEY中获取验证码放到Session中，并从中取出验证码
        String token = (String) req.getSession().getAttribute(KAPTCHA_SESSION_KEY);
        // 删除 Session中的验证码
        req.getSession().removeAttribute(KAPTCHA_SESSION_KEY);

        String username = req.getParameter("username");//  1、获取请求的参数
        String password = req.getParameter("password");
        String email = req.getParameter("email");
        String code = req.getParameter("code");

        //把请求的参数通过WebUtils工具注入javaBean中
        User user = WebUtils.copyParamToBean(req.getParameterMap(),new User());//这样的话，以后的上面的请求参数操作就可以省略
        Map<String,String[]> paramterMap = req.getParameterMap();
        for(Map.Entry<String,String[]> entry:paramterMap.entrySet()){
            System.out.println(entry.getKey()+"=" + Arrays.asList(entry.getValue()));
        }
        if (token!=null&&token.equalsIgnoreCase(code)) {//2、检查 验证码是否更自动生成的匹配并且存在
            //        3、检查 用户名是否可用
            if (userService.existsUsername(username)) {
                System.out.println("用户名[" + username + "]已存在!");
                // 把回显信息，保存到Request域中
                req.setAttribute("msg", "用户名已存在！！");
                req.setAttribute("username", username);
                req.setAttribute("email", email);
                //        跳回注册页面，不可用
                req.getRequestDispatcher("/pages/user/regist.jsp").forward(req, resp);
            } else {
                //      可用
                req.getSession().setAttribute("user",user);//放到session域当中
                //                调用Sservice保存到数据库
                userService.registerUser(new User(null, username, password, email));
                //        跳到注册成功页面 regist_success.html
                req.getRequestDispatcher("/pages/user/regist_success.jsp").forward(req, resp);
            }
        } else {
            //把回显信息，保存到Request域中
            req.setAttribute("msg", "验证码错误！！");
            req.setAttribute("username", username);
            req.setAttribute("email", email);

            System.out.println("验证码[" + code + "]错误");
            req.getRequestDispatcher("/pages/user/regist.jsp").forward(req, resp);
        }
    }

    //doPost()方法不用写了，因为它继承了BaseServlet
}
