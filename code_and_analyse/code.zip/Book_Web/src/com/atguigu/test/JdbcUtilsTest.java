package com.atguigu.test;

import com.atguigu.utils.JdbcUtils;
import org.junit.Test;

import java.sql.Connection;

public class JdbcUtilsTest {

    @Test//这个是导入测试类的架包的，从而完成测试数据库的连接（为hamcrest-core和junit）
    public void testJdbcUtils(){
        for(int i = 0; i < 20;i++){
            Connection connection = JdbcUtils.getConnection();
            System.out.println(connection);
            JdbcUtils.close(connection);//因为设置的最大连接数是10，所以用完就释放，才能一直让我们用
        }
    }

}
