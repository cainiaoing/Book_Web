package com.atguigu.utils;

import org.apache.commons.beanutils.BeanUtils;

import java.util.Map;

public class WebUtils {
    /**
     * Map中的key 是对应的请求参数的变量名，value是从页面填写的值
     * 把Map中的值注入到对应的JavaBean属性中。
     * @param value
     * @param bean
     */
    public static <T> T copyParamToBean( Map value , T bean ){ //泛型的作用是省去了强制类型转化（对对象来说，不用强转，是代码更简洁），
        try {
            System.out.println("注入之前：" + bean);
            /**
             * 把所有请求的参数都注入到user对象中，user实质是javaBean对象,这样就省去了在Servlet的java代码中获取请求信息
             */
            BeanUtils.populate(bean, value);
            System.out.println("注入之后：" + bean);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return bean;
    }

    //将String类型的id,转换成int类型的id
    public static int parseInt(String id, int i) {
        try{
            System.out.println(Integer.parseInt(id));
            return Integer.parseInt(id);
        }catch (Exception e){
            e.printStackTrace();
        }
        return i;
    }
}
