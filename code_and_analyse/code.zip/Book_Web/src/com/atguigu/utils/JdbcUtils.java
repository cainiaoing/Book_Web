package com.atguigu.utils;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.pool.DruidDataSourceFactory;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;
//主要有两个，一个是数据库的连接，一个是数据库连接的关闭
public class JdbcUtils {

    private static DruidDataSource dataSource;//连接池数据资源

    static {
        try {
            Properties properties = new Properties();//从properties配置文件中获取jdbc资源
            // 读取 jdbc.properties属性配置文件以输入输出流的方式
            InputStream inputStream = JdbcUtils.class.getClassLoader().getResourceAsStream("jdbc.properties");
            // 从流中加载数据
            properties.load(inputStream);
            // 创建 数据库连接 池
            dataSource = (DruidDataSource) DruidDataSourceFactory.createDataSource(properties);
            System.out.println( dataSource.getConnection());
        } catch (NumberFormatException e){
            e.printStackTrace();
        }catch (Exception e) {
            e.printStackTrace();
        }

    }

    /**
     * 获取数据库连接池中的连接
     * @return 如果返回null,说明获取连接失败<br/>有值就是获取连接成功
     */
    public static Connection getConnection(){

        Connection conn = null;

        try {
            conn = dataSource.getConnection();//获取连接
        } catch (Exception e) {
            e.printStackTrace();
        }

        return conn;
    }

    /**
     * 关闭连接，放回数据库连接池
     */
    public static void close(Connection conn){
        if (conn != null) {
            try {
                conn.close();//释放资源
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

}

