package com.atguigu.dao;

import com.atguigu.pojo.OrderItem;

import java.util.List;

public interface OrderItemDao {
    public int saveOrderItem(OrderItem orderItem);//保存订单项
    public List<OrderItem> queryOrderItemByOrderId(String orderId);//查询订单项
}
