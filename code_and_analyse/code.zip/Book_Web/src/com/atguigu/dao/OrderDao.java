package com.atguigu.dao;

import com.atguigu.pojo.Order;

import java.util.List;

public interface OrderDao {

    public int saveOrder(Order order);//保存订单
    public List<Order> queryOrders();
    public int changeOrderStatus(String orderId, int status);
    public List<Order> queryOrdersByUserId(Integer userId);

}
